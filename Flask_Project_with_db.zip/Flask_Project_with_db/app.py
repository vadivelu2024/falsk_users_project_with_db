from flask import Flask, render_template, request
from flask_restful import Api
from resources.user import User
from db import get_connection

app = Flask(__name__)
api = Api(app)

# RESTful GET/POST endpoint
api.add_resource(User, '/api/users')

@app.route('/')
def index():
    return render_template('form.html')

@app.route('/submit_user', methods=['POST'])
def submit_user():
    name = request.form['name']
    email = request.form['email']
    
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (name, email) VALUES (%s, %s)", (name, email))
    conn.commit()
    cursor.close()
    conn.close()
    
    return f"<h3>User {name} added successfully!</h3><a href='/'>Go back</a> | <a href='/all_users'>View Users</a>"

@app.route('/all_users')
def all_users():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users")
    users = cursor.fetchall()
    cursor.close()
    conn.close()

    return render_template('users.html', users=users)

if __name__ == '__main__':
    app.run(debug=True)
